from flask import Flask, render_template_string, request, redirect, url_for, session, send_from_directory
import os
from werkzeug.utils import secure_filename
from datetime import datetime

# --- Flask App Initialization ---
app = Flask(__name__)
app.secret_key = 'your_strong_secret_key_for_security' # IMPORTANT: Change this to a strong, random key!

# --- Configuration ---
UPLOAD_BASE = 'static/uploads'
CATEGORIES = ['ia1', 'ia2', 'model', 'lastyear'] # Define your categories
ALLOWED_EXTENSIONS = {'pdf'} # ADD THIS LINE: Define allowed file extensions

# Create category directories if they don't exist
for category in CATEGORIES:
    os.makedirs(os.path.join(UPLOAD_BASE, category), exist_ok=True)

def allowed_file(filename):
    """Checks if a file has an allowed extension."""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# --- Routes ---

@app.route('/')
def home():
    """Renders the home page with category buttons."""
    # Mapping categories to FontAwesome icons (choose appropriate ones)
    category_icons = {
        'ia1': 'fa-lightbulb',    # Example icon for IA1
        'ia2': 'fa-book-open',    # Example icon for IA2
        'model': 'fa-cogs',       # Example icon for Model Papers
        'lastyear': 'fa-history'  # Example icon for Last Year Papers
    }
    return render_template_string(home_template, categories=CATEGORIES, category_icons=category_icons, admin_logged_in=session.get('admin'))

@app.route('/category/<string:category_name>')
def show_category(category_name):
    """Renders a page for a specific category, displaying its papers."""
    if category_name not in CATEGORIES:
        return "Category not found", 404

    papers = []
    folder = os.path.join(UPLOAD_BASE, category_name)
    if os.path.exists(folder):
        # Filtering for search query within the specific category page
        search_query = request.args.get('search', '').lower()
        for f in os.listdir(folder):
            if allowed_file(f):
                file_path = os.path.join(folder, f)
                if search_query in f.lower() or not search_query: # Only filter by filename here
                    papers.append((f, datetime.fromtimestamp(os.path.getmtime(file_path)).strftime('%Y-%m-%d %I:%M %p')))
    
    # Sort papers alphabetically by filename
    papers = sorted(papers, key=lambda x: x[0].lower())

    return render_template_string(category_page_template,
                                  category=category_name,
                                  papers=papers,
                                  admin_logged_in=session.get('admin'))

@app.route('/login', methods=['POST'])
def login():
    """Handles admin login."""
    if request.form.get('username') == 'admin' and request.form.get('password') == '1234':
        session['admin'] = True
    return redirect(url_for('home'))

@app.route('/upload', methods=['GET', 'POST'])
def upload():
    """Handles uploading new question papers."""
    if not session.get('admin'):
        return redirect(url_for('home')) # Redirect if not admin
    if request.method == 'POST':
        title = request.form['title']
        category = request.form['category']
        file = request.files['file']

        if file and allowed_file(file.filename):
            base_filename = secure_filename(title)
            filename = f"{base_filename}.pdf"
            filepath = os.path.join(UPLOAD_BASE, category, filename)

            # Ensure unique filename by appending a counter if file exists
            counter = 1
            while os.path.exists(filepath):
                filename = f"{base_filename}_{counter}.pdf"
                filepath = os.path.join(UPLOAD_BASE, category, filename)
                counter += 1
            file.save(filepath)
            # Redirect to the specific category page after upload
            return redirect(url_for('show_category', category_name=category))
    return render_template_string(upload_template, categories=CATEGORIES)

@app.route('/delete/<category>/<filename>')
def delete_file(category, filename):
    """Handles deleting question papers (admin only)."""
    if session.get('admin'):
        filepath = os.path.join(UPLOAD_BASE, category, filename)
        if os.path.exists(filepath):
            os.remove(filepath)
    # Redirect back to the specific category page after deletion
    return redirect(url_for('show_category', category_name=category))

@app.route('/logout')
def logout():
    """Logs out the admin user."""
    session.pop('admin', None)
    return redirect(url_for('home'))

@app.route('/download/<category>/<filename>')
def download_file(category, filename):
    """
    Serves files for download. Note: The HTML directly links to static files,
    so this route is more for demonstrating server-side file serving if needed.
    """
    return send_from_directory(os.path.join(app.root_path, UPLOAD_BASE, category), filename)

# --- HTML Templates (as strings) ---

home_template = """
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Question Paper Hub</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@600&family=Nunito:wght@400;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    * { box-sizing: border-box; }
    body {
      margin: 0;
      padding: 0;
      font-family: 'Nunito', sans-serif;
      background: linear-gradient(135deg, #e0f7fa, #ffe0f7);
      overflow-x: hidden;
      position: relative;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }
    header {
      background: linear-gradient(to right, #00c9ff, #92fe9d);
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 15px 30px;
      position: relative;
      z-index: 2;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1); /* Added shadow to header */
    }
    header h1 {
      margin: 0;
      font-family: 'Orbitron', sans-serif;
      color: #333;
      text-shadow: 1px 1px 2px rgba(0,0,0,0.05);
    }
    .admin-btn {
      background: #00c9ff;
      color: white;
      border: none;
      padding: 8px 14px;
      border-radius: 8px;
      font-weight: bold;
      cursor: pointer;
      transition: background-color 0.3s ease, transform 0.2s ease;
    }
    .admin-btn:hover {
        background-color: #00a0e0;
        transform: translateY(-2px);
    }

    /* Admin Login Overlay */
    .login-overlay {
        display: none; /* Hidden by default */
        position: fixed; /* Stays on top of everything */
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.6); /* Semi-transparent black background */
        z-index: 1000; /* High z-index to cover everything */
        justify-content: center; /* Center horizontally */
        align-items: center; /* Center vertically */
        backdrop-filter: blur(5px); /* Frosted glass effect */
        opacity: 0;
        transition: opacity 0.3s ease-in-out;
    }
    .login-overlay.visible {
        display: flex; /* Show when active */
        opacity: 1;
    }
    .login-box {
        background: linear-gradient(135deg, #ff9a9e 0%, #fad0c4 99%, #fad0c4 100%); /* Bright gradient */
        padding: 30px;
        border-radius: 15px;
        box-shadow: 0 15px 40px rgba(0, 0, 0, 0.3); /* Stronger shadow */
        text-align: center;
        transform: translateY(-20px); /* Initial slight lift */
        transition: transform 0.3s ease-out, opacity 0.3s ease-out;
        width: 300px;
        max-width: 90%;
        position: relative; /* For the close button */
    }
    .login-overlay.visible .login-box {
        transform: translateY(0); /* Animate to center */
    }
    .login-box h2 {
        color: #fff; /* White text for contrast */
        margin-bottom: 25px;
        text-shadow: 1px 1px 3px rgba(0,0,0,0.2);
        font-family: 'Orbitron', sans-serif;
    }
    .login-box input {
        width: calc(100% - 20px);
        padding: 12px;
        margin-bottom: 15px;
        border: none; /* No border */
        border-radius: 8px;
        background-color: rgba(255, 255, 255, 0.9); /* Slightly transparent white */
        font-size: 1em;
        color: #333;
        box-shadow: inset 0 2px 5px rgba(0,0,0,0.1);
    }
    .login-box input::placeholder {
        color: #666;
    }
    .login-box button {
        background: linear-gradient(to right, #00c9ff, #92fe9d); /* Blue-green gradient */
        color: white;
        border: none;
        padding: 12px 25px;
        border-radius: 8px;
        font-weight: bold;
        cursor: pointer;
        transition: all 0.3s ease;
        width: 100%;
        font-size: 1.1em;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    }
    .login-box button:hover {
        opacity: 0.9;
        transform: translateY(-2px);
        box-shadow: 0 8px 20px rgba(0,0,0,0.3);
    }
    .login-box .close-btn {
        position: absolute;
        top: 10px;
        right: 10px;
        background: none;
        border: none;
        font-size: 1.5em;
        color: rgba(255, 255, 255, 0.8);
        cursor: pointer;
        transition: color 0.2s ease;
    }
    .login-box .close-btn:hover {
        color: white;
    }


    /* Enhanced styles for category buttons on the home page */
    .category-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); /* Slightly wider buttons */
      gap: 35px; /* More space */
      padding: 50px;
      justify-content: center;
      align-items: center;
      flex-grow: 1;
      max-width: 1280px; /* Wider content area */
      margin: 0 auto;
      position: relative;
      z-index: 1;
    }
    .category-button {
      background: linear-gradient(145deg, #ffffff, #f0f0f0); /* Subtle gradient */
      border: none; /* Remove border, rely on shadow */
      border-radius: 25px; /* More rounded */
      padding: 60px 30px; /* Even larger padding */
      text-align: center;
      text-decoration: none;
      color: #2c3e50; /* Darker text for contrast */
      font-size: 2.5em; /* Larger font size */
      font-weight: 700; /* Bolder font */
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      box-shadow: 0 10px 30px rgba(0,0,0,0.1); /* Softer, larger shadow */
      transition: all 0.3s ease-in-out; /* Smoother transition */
      cursor: pointer;
      position: relative;
      overflow: hidden; /* Hide overflow for pseudo-elements */
    }
    .category-button:before { /* Pseudo-element for hover background */
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(45deg, #00c9ff, #92fe9d); /* Hover gradient */
        opacity: 0;
        transition: opacity 0.3s ease-in-out;
        z-index: 0;
    }
    .category-button:hover:before {
        opacity: 1;
    }
    .category-button:hover {
      transform: translateY(-8px); /* More pronounced lift */
      box-shadow: 0 15px 40px rgba(0,0,0,0.2); /* Deeper shadow on hover */
      color: white; /* Text turns white on hover */
    }
    .category-button .icon {
        font-size: 1.5em; /* Icon size relative to text */
        margin-bottom: 15px; /* Space between icon and text */
        color: #00c9ff; /* Icon initial color */
        transition: color 0.3s ease-in-out;
        position: relative;
        z-index: 1; /* Keep icon above pseudo-element */
    }
    .category-button:hover .icon {
        color: white; /* Icon turns white on hover */
    }
    .category-button span { /* For the text */
        position: relative;
        z-index: 1; /* Keep text above pseudo-element */
        transition: color 0.3s ease-in-out;
    }

    .svg-bg {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 0;
      opacity: 0.2;
      overflow: hidden;
    }
    .svg-bg svg {
        position: absolute;
    }
    .svg-bg .circle1 {
        top: -50px;
        left: -50px;
        width: 300px;
        height: 300px;
        fill: #00c9ff;
        filter: blur(10px); /* Soften the edges */
    }
    .svg-bg .circle2 {
        bottom: -80px; /* Positioned from bottom */
        right: -80px; /* Positioned from right */
        width: 350px;
        height: 350px;
        fill: #92fe9d;
        opacity: 0.4;
        filter: blur(15px); /* More blur */
        transform: rotate(45deg);
    }
    .svg-bg .circle3 {
        top: 20%;
        left: 40%;
        width: 180px;
        height: 180px;
        fill: #ffcc80;
        opacity: 0.3;
        filter: blur(8px);
        transform: rotate(15deg);
    }

    @media (max-width: 768px) {
        header {
            flex-direction: column;
            padding: 10px;
        }
        .login-overlay .login-box { /* Adjust login box for small screens */
            width: 95%;
            padding: 20px;
        }
        .category-grid {
            grid-template-columns: 1fr;
            padding: 20px;
        }
        .category-button {
            font-size: 2em;
            padding: 50px 20px;
        }
    }
  </style>
</head>
<body>
<div class="svg-bg">
    <svg class="circle1" viewBox="0 0 400 400">
      <circle cx="200" cy="200" r="200"/>
    </svg>
    <svg class="circle2" viewBox="0 0 400 400">
        <circle cx="200" cy="200" r="200"/>
    </svg>
    <svg class="circle3" viewBox="0 0 400 400">
        <circle cx="200" cy="200" r="200"/>
    </svg>
</div>

<header>
  <h1>📘 Question Paper Hub</h1>
  {% if admin_logged_in %}
    <form action="/logout" method="get">
      <button class="admin-btn">Logout</button>
    </form>
  {% else %}
    <div>
      <button class="admin-btn" onclick="showLoginOverlay()">Admin Login</button>
    </div>
  {% endif %}
</header>

<main class="category-grid">
  {% for cat in categories %}
    <a href="{{ url_for('show_category', category_name=cat) }}" class="category-button">
      <i class="fas {{ category_icons[cat] }} icon"></i> <span>{{ cat.upper() }}</span>
    </a>
  {% endfor %}
</main>

<div class="login-overlay" id="loginOverlay">
    <div class="login-box">
        <button class="close-btn" onclick="hideLoginOverlay()">&times;</button>
        <h2>Admin Login</h2>
        <form action="/login" method="post">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>
    </div>
</div>


<script>
  // Show login overlay
  function showLoginOverlay() {
    document.getElementById('loginOverlay').classList.add('visible');
  }

  // Hide login overlay
  function hideLoginOverlay() {
    document.getElementById('loginOverlay').classList.remove('visible');
  }

  // Dismiss login overlay when clicking outside the login box
  document.getElementById('loginOverlay').addEventListener('click', function(event) {
    if (event.target === this) { // Only hide if the overlay itself was clicked, not its children
      hideLoginOverlay();
    }
  });

  // Prevent login box from closing when clicking inside it
  document.querySelector('.login-box').addEventListener('click', function(event) {
    event.stopPropagation(); // Stop event from bubbling up to the overlay
  });
</script>
</body>
</html>
"""

category_page_template = """
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>{{ category.upper() }} Papers - Question Paper Hub</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@600&family=Nunito:wght@400;700&display=swap" rel="stylesheet">
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    * { box-sizing: border-box; }
    body {
      margin: 0;
      padding: 0;
      font-family: 'Nunito', sans-serif;
      background: linear-gradient(135deg, #e0f7fa, #ffe0f7);
      overflow-x: hidden;
    }
    header {
      background: linear-gradient(to right, #00c9ff, #92fe9d);
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 15px 30px;
      position: relative;
      z-index: 2;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    header h1 {
      margin: 0;
      font-family: 'Orbitron', sans-serif;
      color: #333;
    }
    .admin-btn, .search-btn {
      background: #00c9ff;
      color: white;
      border: none;
      padding: 8px 14px;
      border-radius: 8px;
      font-weight: bold;
      cursor: pointer;
      transition: background-color 0.3s ease, transform 0.2s ease;
    }
    .admin-btn:hover, .search-btn:hover {
        background-color: #00a0e0;
        transform: translateY(-2px);
    }

    /* Admin Login Overlay (Copied from home_template for consistency if needed on category pages) */
    .login-overlay {
        display: none; /* Hidden by default */
        position: fixed; /* Stays on top of everything */
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.6); /* Semi-transparent black background */
        z-index: 1000; /* High z-index to cover everything */
        justify-content: center; /* Center horizontally */
        align-items: center; /* Center vertically */
        backdrop-filter: blur(5px); /* Frosted glass effect */
        opacity: 0;
        transition: opacity 0.3s ease-in-out;
    }
    .login-overlay.visible {
        display: flex; /* Show when active */
        opacity: 1;
    }
    .login-box {
        background: linear-gradient(135deg, #ff9a9e 0%, #fad0c4 99%, #fad0c4 100%); /* Bright gradient */
        padding: 30px;
        border-radius: 15px;
        box-shadow: 0 15px 40px rgba(0, 0, 0, 0.3); /* Stronger shadow */
        text-align: center;
        transform: translateY(-20px); /* Initial slight lift */
        transition: transform 0.3s ease-out, opacity 0.3s ease-out;
        width: 300px;
        max-width: 90%;
        position: relative; /* For the close button */
    }
    .login-overlay.visible .login-box {
        transform: translateY(0); /* Animate to center */
    }
    .login-box h2 {
        color: #fff; /* White text for contrast */
        margin-bottom: 25px;
        text-shadow: 1px 1px 3px rgba(0,0,0,0.2);
        font-family: 'Orbitron', sans-serif;
    }
    .login-box input {
        width: calc(100% - 20px);
        padding: 12px;
        margin-bottom: 15px;
        border: none; /* No border */
        border-radius: 8px;
        background-color: rgba(255, 255, 255, 0.9); /* Slightly transparent white */
        font-size: 1em;
        color: #333;
        box-shadow: inset 0 2px 5px rgba(0,0,0,0.1);
    }
    .login-box input::placeholder {
        color: #666;
    }
    .login-box button {
        background: linear-gradient(to right, #00c9ff, #92fe9d); /* Blue-green gradient */
        color: white;
        border: none;
        padding: 12px 25px;
        border-radius: 8px;
        font-weight: bold;
        cursor: pointer;
        transition: all 0.3s ease;
        width: 100%;
        font-size: 1.1em;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    }
    .login-box button:hover {
        opacity: 0.9;
        transform: translateY(-2px);
        box-shadow: 0 8px 20px rgba(0,0,0,0.3);
    }
    .login-box .close-btn {
        position: absolute;
        top: 10px;
        right: 10px;
        background: none;
        border: none;
        font-size: 1.5em;
        color: rgba(255, 255, 255, 0.8);
        cursor: pointer;
        transition: color 0.2s ease;
    }
    .login-box .close-btn:hover {
        color: white;
    }

    .search-container {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-top: 25px;
        margin-bottom: 25px;
        justify-content: center;
    }
    .search-container input {
        padding: 10px 15px;
        border-radius: 10px;
        border: 1px solid #ccc;
        width: 350px;
        max-width: 85%;
        box-shadow: inset 0 1px 3px rgba(0,0,0,0.05);
    }
    .search-btn {
        padding: 10px 18px;
        border-radius: 10px;
        font-size: 1em;
    }
    .category-heading {
        text-align: center;
        margin: 30px 0 20px;
        color: #333;
        font-family: 'Orbitron', sans-serif;
        text-shadow: 1px 1px 2px rgba(0,0,0,0.05);
    }
    .card-list {
        max-width: 750px;
        margin: 0 auto;
        padding: 0 25px;
    }
    .card {
      background: white;
      margin: 20px auto;
      padding: 25px;
      border-radius: 18px;
      box-shadow: 0 8px 25px rgba(0,0,0,0.12);
      position: relative;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
    }
    .card:hover {
        transform: translateY(-3px);
        box-shadow: 0 12px 30px rgba(0,0,0,0.18);
    }
    .card a {
      color: #007bff;
      text-decoration: none;
      font-weight: bold;
      flex-grow: 1;
      font-size: 1.1em;
    }
    .card a:hover {
        text-decoration: underline;
    }
    .card small {
      color: #666;
      display: block;
      margin-top: 8px;
      font-size: 0.9em;
    }
    .card-actions {
        display: flex;
        gap: 12px;
        margin-left: 20px;
    }
    .download-btn, .delete-btn {
      padding: 8px 16px;
      font-size: 0.9em;
      border-radius: 8px;
      cursor: pointer;
      border: none;
      transition: background-color 0.3s ease, transform 0.2s ease;
      font-weight: bold;
    }
    .download-btn {
      background: #4CAF50;
      color: white;
    }
    .download-btn:hover {
        background: #45a049;
        transform: translateY(-1px);
    }
    .delete-btn {
      background: #e74c3c;
      color: white;
    }
    .delete-btn:hover {
        background: #c0392b;
        transform: translateY(-1px);
    }
    .admin-controls {
      text-align: center;
      margin-top: 25px;
      margin-bottom: 20px;
    }
    .admin-controls a {
        padding: 10px 20px;
        background: #28a745; /* Green for upload */
        color: white;
        border-radius: 8px;
        text-decoration: none;
        font-weight: bold;
        transition: background-color 0.3s ease, transform 0.2s ease;
    }
    .admin-controls a:hover {
        background: #218838;
        transform: translateY(-2px);
    }
    .back-to-home {
        display: block;
        text-align: center;
        margin: 40px 0 60px;
        font-weight: bold;
        color: #00c9ff;
        text-decoration: none;
        font-size: 1.1em;
        transition: color 0.3s ease;
    }
    .back-to-home:hover {
        color: #007bff;
        text-decoration: underline;
    }

    @media (max-width: 768px) {
        header {
            flex-direction: column;
            padding: 10px;
        }
        .login-overlay .login-box {
            width: 95%;
            padding: 20px;
        }
        .search-container input {
            width: 100%;
        }
        .card {
            flex-direction: column;
            align-items: flex-start;
        }
        .card-actions {
            margin-top: 15px;
            margin-left: 0;
            width: 100%;
            justify-content: flex-end;
        }
    }
  </style>
</head>
<body>
<header>
  <h1>📘 Question Paper Hub</h1>
  {% if admin_logged_in %}
    <form action="/logout" method="get">
      <button class="admin-btn">Logout</button>
    </form>
  {% else %}
    <div>
      <button class="admin-btn" onclick="showLoginOverlay()">Admin Login</button>
    </div>
  {% endif %}
</header>

<h2 class="category-heading">{{ category.upper() }} Question Papers</h2>

<div class="search-container">
    <form action="{{ url_for('show_category', category_name=category) }}" method="get">
        <input type="text" name="search" placeholder="Search papers in {{ category.upper() }}..." value="{{ request.args.get('search', '') }}">
        <button type="submit" class="search-btn">Search</button>
    </form>
</div>

{% if admin_logged_in %}
<div class="admin-controls">
  <a href="{{ url_for('upload') }}">📤 Upload New Paper</a>
</div>
{% endif %}

<div class="card-list">
    {% if papers %}
      {% for file, time in papers %}
        {% if request.args.get('search', '').lower() in file.lower() or not request.args.get('search') %}
            <div class="card" data-aos="fade-up">
              <div>
                <a href="/static/uploads/{{ category }}/{{ file }}" target="_blank">📄 {{ file.replace('.pdf', '') }}</a>
                <small>Uploaded: {{ time }}</small>
              </div>
              <div class="card-actions">
                <a href="/static/uploads/{{ category }}/{{ file }}" target="_blank" download="{{ file }}"><button class="download-btn">Download</button></a>
                {% if admin_logged_in %}
                  <a href="{{ url_for('delete_file', category=category, filename=file) }}"><button class="delete-btn">Delete</button></a>
                {% endif %}
              </div>
            </div>
        {% endif %}
      {% endfor %}
    {% else %}
      <p style="text-align:center;">No papers uploaded yet in {{ category.upper() }} {% if request.args.get('search') %} matching "{{ request.args.get('search') }}"{% endif %}</p>
    {% endif %}
</div>

<a href="{{ url_for('home') }}" class="back-to-home">← Back to Categories</a>

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
  AOS.init();

  // Show login overlay (Copied to category page for consistency)
  function showLoginOverlay() {
    document.getElementById('loginOverlay').classList.add('visible');
  }

  // Hide login overlay
  function hideLoginOverlay() {
    document.getElementById('loginOverlay').classList.remove('visible');
  }

  // Dismiss login overlay when clicking outside the login box
  document.getElementById('loginOverlay').addEventListener('click', function(event) {
    if (event.target === this) {
      hideLoginOverlay();
    }
  });

  // Prevent login box from closing when clicking inside it
  const loginBox = document.querySelector('.login-box');
  if (loginBox) { // Check if element exists before adding listener
      loginBox.addEventListener('click', function(event) {
        event.stopPropagation();
      });
  }
</script>
</body>
</html>
"""

upload_template = """
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Upload Paper</title>
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@600&family=Nunito:wght@400;700&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Nunito', sans-serif;
      background: linear-gradient(135deg, #f6d365, #fda085);
      margin: 0;
      padding: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
    }
    .container {
      max-width: 500px;
      background: white;
      margin: 20px auto;
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0 8px 20px rgba(0,0,0,0.2);
    }
    h2 {
      text-align: center;
      color: #f76b1c;
      margin-bottom: 25px;
      font-family: 'Orbitron', sans-serif;
    }
    form {
      display: flex;
      flex-direction: column;
      gap: 15px;
    }
    input, select {
      padding: 12px;
      font-size: 16px;
      border-radius: 8px;
      border: 1px solid #ddd;
    }
    /* Stylish Upload Button */
    .upload-submit-btn {
      background: linear-gradient(to right, #4CAF50, #8BC34A); /* Green gradient */
      color: white;
      font-weight: bold;
      border: none;
      border-radius: 25px; /* More rounded */
      padding: 15px 30px; /* Larger padding */
      cursor: pointer;
      font-size: 1.2em; /* Larger font */
      transition: all 0.3s ease;
      box-shadow: 0 5px 15px rgba(0,0,0,0.2); /* Soft shadow */
      position: relative;
      overflow: hidden; /* For pseudo-element */
    }
    .upload-submit-btn:before { /* Animated hover effect */
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: rgba(255, 255, 255, 0.2); /* Light overlay */
        transform: skewX(-20deg);
        transition: all 0.5s ease;
    }
    .upload-submit-btn:hover:before {
        left: 100%;
    }
    .upload-submit-btn:hover {
        background: linear-gradient(to right, #388E3C, #689F38); /* Darker green on hover */
        transform: translateY(-3px); /* Lift effect */
        box-shadow: 0 8px 20px rgba(0,0,0,0.3); /* Deeper shadow */
    }

    a {
      display: block;
      margin-top: 25px;
      text-align: center;
      color: #f76b1c;
      text-decoration: none;
      font-weight: bold;
    }
    a:hover {
        text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>📤 Upload Question Paper</h2>
    <form action="/upload" method="post" enctype="multipart/form-data">
      <input type="text" name="title" placeholder="Paper Title" required>
      <select name="category" required>
        <option value="" disabled selected>Select Category</option>
        {% for cat in categories %}
          <option value="{{ cat }}">{{ cat.upper() }}</option>
        {% endfor %}
      </select>
      <input type="file" name="file" accept="application/pdf" required>
      <button type="submit" class="upload-submit-btn">Upload Paper</button>
    </form>
    <a href="/">← Back to Home</a>
  </div>
</body>
</html>
"""

# --- Run the App ---
if __name__ == '__main__':
    app.run(debug=True)
